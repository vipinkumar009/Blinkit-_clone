# Blinkit-style Grocery App (Starter)

**Stack:** Node.js, Express, MongoDB (Mongoose)

This is a starter template for a Blinkit-like online grocery app.
It includes basic models, controllers, routes, and an example server.

## Included files
- `index.js` - app entry (Express)
- `config/db.js` - MongoDB connection helper
- `models/` - Mongoose models:
  - `Catmodel.js`, `Submodel.js`, `Projectmodel.js`, `Customermodel.js`, `Cartmodel.js`, `Ordermodel.js`, `Orderdetails.js`
- `routes/` - sample routes for categories, products, customers, cart, orders
- `controllers/` - basic controller skeletons
- `.env.example` - example environment variables
- `package.json` - dependencies and scripts

## Quick start
1. Copy `.env.example` to `.env` and set `MONGO_URI`.
2. `npm install`
3. `npm run dev` (requires nodemon) or `npm start`

## Notes
- This is a starter scaffold with basic CRUD endpoints and example schemas.
- Extend authentication, validation, and frontend as needed.
