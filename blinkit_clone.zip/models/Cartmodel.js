const mongoose = require('mongoose');
const CartSchema = new mongoose.Schema({
  customer: { type: mongoose.Schema.Types.ObjectId, ref: 'Customer', required: true },
  items: [{
    product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
    qty: { type: Number, default: 1 },
    price: Number
  }],
  updatedAt: { type: Date, default: Date.now }
});
module.exports = mongoose.model('Cart', CartSchema);
