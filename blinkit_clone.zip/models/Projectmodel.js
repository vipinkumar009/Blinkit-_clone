const mongoose = require('mongoose');
// 'Projectmodel' used for products/items in store
const ProductSchema = new mongoose.Schema({
  name: { type: String, required: true },
  sku: { type: String, unique: true },
  category: { type: mongoose.Schema.Types.ObjectId, ref: 'Category' },
  subcategory: { type: mongoose.Schema.Types.ObjectId, ref: 'Subcategory' },
  price: { type: Number, required: true },
  mrp: { type: Number },
  unit: { type: String },
  stock: { type: Number, default: 0 },
  images: [String],
  description: String,
  createdAt: { type: Date, default: Date.now }
});
module.exports = mongoose.model('Product', ProductSchema);
