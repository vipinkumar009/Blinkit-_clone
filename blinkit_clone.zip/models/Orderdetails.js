const mongoose = require('mongoose');
const OrderItemSchema = new mongoose.Schema({
  product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
  qty: Number,
  price: Number
}, { _id: false });
module.exports = OrderItemSchema;
