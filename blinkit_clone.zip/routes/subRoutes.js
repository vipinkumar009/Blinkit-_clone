const express = require('express');
const router = express.Router();
// Simple inline handlers for subcategories (extend as needed)
const Sub = require('../models/Submodel');
router.post('/', async (req, res) => {
  const s = await Sub.create(req.body);
  res.status(201).json(s);
});
router.get('/', async (req, res) => {
  const list = await Sub.find().populate('category');
  res.json(list);
});
module.exports = router;
