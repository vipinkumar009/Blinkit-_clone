const Cart = require('../models/Cartmodel');
exports.get = async (req, res) => {
  const cart = await Cart.findOne({ customer: req.params.customer }).populate('items.product');
  res.json(cart || { items: [] });
};
exports.addItem = async (req, res) => {
  const { customer } = req.body;
  let cart = await Cart.findOne({ customer });
  if (!cart) cart = await Cart.create({ customer, items: [] });
  cart.items.push(req.body.item);
  await cart.save();
  res.json(cart);
};
