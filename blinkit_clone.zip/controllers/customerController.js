const Customer = require('../models/Customermodel');
const bcrypt = require('bcryptjs');
exports.register = async (req, res) => {
  try {
    const { name, email, password } = req.body;
    const salt = await bcrypt.genSalt(10);
    const hash = await bcrypt.hash(password, salt);
    const c = await Customer.create({ name, email, password: hash });
    res.status(201).json({ id: c._id, name: c.name, email: c.email });
  } catch (err) { res.status(400).json({ error: err.message }); }
};
