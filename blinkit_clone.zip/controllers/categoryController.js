const Category = require('../models/Catmodel');
exports.create = async (req, res) => {
  try {
    const c = await Category.create(req.body);
    res.status(201).json(c);
  } catch (err) { res.status(400).json({ error: err.message }); }
};
exports.list = async (req, res) => {
  const cats = await Category.find();
  res.json(cats);
};
