const Product = require('../models/Projectmodel');
exports.create = async (req, res) => {
  try {
    const p = await Product.create(req.body);
    res.status(201).json(p);
  } catch (err) { res.status(400).json({ error: err.message }); }
};
exports.list = async (req, res) => {
  const list = await Product.find().populate('category subcategory');
  res.json(list);
};
