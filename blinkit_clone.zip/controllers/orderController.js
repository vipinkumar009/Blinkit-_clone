const Order = require('../models/Ordermodel');
exports.create = async (req, res) => {
  const { customer, items, total } = req.body;
  const o = await Order.create({ customer, items, total });
  res.status(201).json(o);
};
exports.list = async (req, res) => {
  const list = await Order.find().populate('customer');
  res.json(list);
};
